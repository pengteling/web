(function( $ ) { 
$.fn.myPlugin = function() { 
// 这里开始写功能需求 
	
			alert("plugin");
		
}; 
})( jQuery ); 